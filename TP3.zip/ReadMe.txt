Name: Bollywood Run

Description: Bollywood Run is a game that will allow users to collect beats of a song while facing difficulties with obstacles and levels. There are 3 modes to choose from. Single player, Multi player (which allows you to play with a friend), and Computer Player (where you compete against an AI player). 

How to Run The Project:
The user should have all the design and music files in a single folder. Then they should run TP3.3.py in an editor to play the game. Visual Studio Code is a great editor to use to run the file. Make sure to install all of the required libraries to run the game.

Libraries to be Installed:
math
random
PIL
string
os
tkinter
pygame
aubio
numpy

Shortcut Commands:
- Enter --> Ends game where it currently is and goes to next screen (Statistics Screen)
- q --> Quits game
- p --> Pauses game
- h --> Goes to Help Screen